"""
PennyWise - Personal Expense Tracker
Database Package
"""

from .db_manager import DatabaseManager

__all__ = ['DatabaseManager']
