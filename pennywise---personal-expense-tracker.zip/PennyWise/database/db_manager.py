"""
PennyWise - Personal Expense Tracker
Module: database/db_manager.py
Demonstrates:
- Encapsulation of SQLite connection, transactions, and SQL statements
- Separation of Concerns: isolated data layer communicating via domain objects
"""

import sqlite3
import os
from typing import List, Optional, Dict, Any, Tuple
from datetime import datetime, timedelta
import random

from models.expense import Expense
from models.category import Category
from models.budget import Budget


class DatabaseManager:
    """
    Manages persistent SQLite operations for PennyWise.
    Encapsulates schema creation, connections, CRUD operations, and transaction management.
    """

    def __init__(self, db_path: str = "pennywise.db"):
        self._db_path = db_path
        self.init_db()

    @property
    def db_path(self) -> str:
        return self._db_path

    def _get_connection(self) -> sqlite3.Connection:
        """Create and return a thread-safe connection to the SQLite database."""
        conn = sqlite3.connect(self._db_path, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        # Enable foreign key support in SQLite
        conn.execute("PRAGMA foreign_keys = ON;")
        return conn

    def init_db(self) -> None:
        """Creates tables if they do not exist and initializes default seed data."""
        with self._get_connection() as conn:
            cursor = conn.cursor()

            # Categories table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS categories (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT UNIQUE NOT NULL,
                    icon TEXT NOT NULL,
                    color TEXT NOT NULL,
                    budget_limit REAL DEFAULT 0.0
                );
            """)

            # Expenses table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS expenses (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    title TEXT NOT NULL,
                    amount REAL NOT NULL CHECK(amount > 0),
                    category TEXT NOT NULL,
                    date TEXT NOT NULL,
                    description TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                );
            """)

            # Budgets table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS budgets (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    month TEXT UNIQUE NOT NULL,
                    amount REAL NOT NULL CHECK(amount >= 0),
                    alert_threshold REAL DEFAULT 80.0,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                );
            """)

            conn.commit()

        # Seed categories if table is empty
        self.seed_default_categories()

        # Seed initial sample expenses and budget if database is newly initialized
        self._seed_initial_data_if_empty()

    def seed_default_categories(self) -> None:
        """Ensure standard categories exist in the database."""
        defaults = [
            ("Food", "utensils", "#10B981", 600.0),
            ("Transport", "car", "#3B82F6", 250.0),
            ("Shopping", "shopping-bag", "#F59E0B", 400.0),
            ("Education", "graduation-cap", "#8B5CF6", 200.0),
            ("Entertainment", "film", "#EC4899", 200.0),
            ("Bills", "receipt", "#EF4444", 800.0),
            ("Healthcare", "heart-pulse", "#14B8A6", 300.0),
            ("Others", "tag", "#6B7280", 150.0)
        ]

        with self._get_connection() as conn:
            cursor = conn.cursor()
            for name, icon, color, limit in defaults:
                cursor.execute("""
                    INSERT OR IGNORE INTO categories (name, icon, color, budget_limit)
                    VALUES (?, ?, ?, ?);
                """, (name, icon, color, limit))
            conn.commit()

    def _seed_initial_data_if_empty(self) -> None:
        """Auto-seed sample transactions and budget if table is empty on first run."""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT COUNT(*) as count FROM expenses;")
            row = cursor.fetchone()
            if row and row["count"] == 0:
                self.seed_sample_data()

    def seed_sample_data(self) -> None:
        """Populate realistic sample expenses across current and previous weeks."""
        today = datetime.now()
        current_month = today.strftime("%Y-%m")

        # Set default budget for current month ($2,500 with 80% threshold)
        self.save_budget(Budget(monthly_limit=2500.0, month=current_month, alert_threshold=80.0))

        # Sample realistic transactions
        samples = [
            ("Whole Foods Groceries", 112.45, "Food", today.strftime("%Y-%m-%d"), "Weekly organic groceries & vegetables"),
            ("Metro Monthly Pass", 75.00, "Transport", (today - timedelta(days=1)).strftime("%Y-%m-%d"), "Public transit card recharge"),
            ("Electric & Utilities Bill", 145.80, "Bills", (today - timedelta(days=2)).strftime("%Y-%m-%d"), "City power & municipal utilities"),
            ("Tech Bookstore - Python OOP", 49.99, "Education", (today - timedelta(days=3)).strftime("%Y-%m-%d"), "Design Patterns in Python reference"),
            ("Blue Bottle Coffee & Pastry", 14.50, "Food", (today - timedelta(days=4)).strftime("%Y-%m-%d"), "Morning team meetup"),
            ("Weekend Cinema IMAX", 38.00, "Entertainment", (today - timedelta(days=5)).strftime("%Y-%m-%d"), "Two tickets with popcorn"),
            ("Pharmacy Prescription Refill", 42.15, "Healthcare", (today - timedelta(days=6)).strftime("%Y-%m-%d"), "Monthly vitamins and medicines"),
            ("Nordstrom Jacket Sale", 129.90, "Shopping", (today - timedelta(days=8)).strftime("%Y-%m-%d"), "Winter casual wear"),
            ("High-Speed Fiber Internet", 65.00, "Bills", (today - timedelta(days=10)).strftime("%Y-%m-%d"), "Gigabit internet subscription"),
            ("Trader Joe's Snack Haul", 54.30, "Food", (today - timedelta(days=12)).strftime("%Y-%m-%d"), "Snacks, fruits, and sparkling water"),
            ("Gasoline Fuel Fill-up", 48.75, "Transport", (today - timedelta(days=14)).strftime("%Y-%m-%d"), "Full tank Shell 93 Octane"),
            ("Online Python Course", 89.00, "Education", (today - timedelta(days=16)).strftime("%Y-%m-%d"), "Advanced Software Engineering Certificate"),
            ("Spotify & Netflix Bundle", 29.98, "Entertainment", (today - timedelta(days=18)).strftime("%Y-%m-%d"), "Monthly streaming subscriptions"),
            ("Dental Hygiene Checkup", 95.00, "Healthcare", (today - timedelta(days=20)).strftime("%Y-%m-%d"), "Routine 6-month cleaning"),
            ("Home Office Ergonomic Mouse", 68.50, "Shopping", (today - timedelta(days=22)).strftime("%Y-%m-%d"), "Logitech wireless ergonomic mouse")
        ]

        with self._get_connection() as conn:
            cursor = conn.cursor()
            for title, amt, cat, dt, desc in samples:
                cursor.execute("""
                    INSERT INTO expenses (title, amount, category, date, description)
                    VALUES (?, ?, ?, ?, ?);
                """, (title, amt, cat, dt, desc))
            conn.commit()

    def clear_all_data(self) -> None:
        """Clear all transactions and custom budgets (preserves categories)."""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM expenses;")
            cursor.execute("DELETE FROM budgets;")
            cursor.execute("DELETE FROM sqlite_sequence WHERE name IN ('expenses', 'budgets');")
            conn.commit()

    # --- Expense CRUD Operations (Returns OOP Expense objects) ---

    def add_expense(self, expense: Expense) -> Expense:
        """Insert a new expense into SQLite and return with assigned ID."""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO expenses (title, amount, category, date, description)
                VALUES (?, ?, ?, ?, ?);
            """, (expense.title, expense.amount, expense.category, expense.date, expense.description))
            conn.commit()
            expense.id = cursor.lastrowid
            return expense

    def get_expense_by_id(self, expense_id: int) -> Optional[Expense]:
        """Fetch a single expense by ID and construct an OOP Expense instance."""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM expenses WHERE id = ?;", (expense_id,))
            row = cursor.fetchone()
            if not row:
                return None
            return Expense(
                transaction_id=row["id"],
                title=row["title"],
                amount=row["amount"],
                category=row["category"],
                date=row["date"],
                description=row["description"] or "",
                created_at=row["created_at"]
            )

    def get_all_expenses(
        self,
        search: Optional[str] = None,
        category: Optional[str] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        sort_by: str = "date",
        order: str = "DESC"
    ) -> List[Expense]:
        """Query expenses with filtering, searching, and sorting."""
        query = "SELECT * FROM expenses WHERE 1=1"
        params: List[Any] = []

        if search:
            query += " AND (title LIKE ? OR description LIKE ?)"
            term = f"%{search.strip()}%"
            params.extend([term, term])

        if category and category.lower() != "all":
            query += " AND LOWER(category) = LOWER(?)"
            params.append(category.strip())

        if start_date:
            query += " AND date >= ?"
            params.append(start_date.strip())

        if end_date:
            query += " AND date <= ?"
            params.append(end_date.strip())

        # Safe sorting parameters
        valid_sort_cols = {
            "date": "date",
            "amount": "amount",
            "title": "title",
            "category": "category",
            "id": "id"
        }
        sort_col = valid_sort_cols.get(sort_by.lower(), "date")
        sort_order = "ASC" if order.upper() == "ASC" else "DESC"

        query += f" ORDER BY {sort_col} {sort_order}, id DESC;"

        expenses: List[Expense] = []
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(query, params)
            for row in cursor.fetchall():
                exp = Expense(
                    transaction_id=row["id"],
                    title=row["title"],
                    amount=row["amount"],
                    category=row["category"],
                    date=row["date"],
                    description=row["description"] or "",
                    created_at=row["created_at"]
                )
                expenses.append(exp)

        return expenses

    def update_expense(self, expense: Expense) -> bool:
        """Update an existing expense in the database."""
        if not expense.id:
            raise ValueError("Expense must have an assigned ID to be updated.")

        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                UPDATE expenses
                SET title = ?, amount = ?, category = ?, date = ?, description = ?
                WHERE id = ?;
            """, (expense.title, expense.amount, expense.category, expense.date, expense.description, expense.id))
            conn.commit()
            return cursor.rowcount > 0

    def delete_expense(self, expense_id: int) -> bool:
        """Delete an expense by its ID."""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM expenses WHERE id = ?;", (expense_id,))
            conn.commit()
            return cursor.rowcount > 0

    # --- Budget Operations ---

    def get_budget_for_month(self, month: str) -> Optional[Budget]:
        """Retrieve budget entity for a target month (YYYY-MM)."""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM budgets WHERE month = ?;", (month,))
            row = cursor.fetchone()
            if not row:
                return None
            return Budget(
                budget_id=row["id"],
                monthly_limit=row["amount"],
                month=row["month"],
                alert_threshold=row["alert_threshold"],
                updated_at=row["updated_at"]
            )

    def save_budget(self, budget: Budget) -> Budget:
        """Upsert a monthly budget record."""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO budgets (month, amount, alert_threshold, updated_at)
                VALUES (?, ?, ?, CURRENT_TIMESTAMP)
                ON CONFLICT(month) DO UPDATE SET
                    amount = excluded.amount,
                    alert_threshold = excluded.alert_threshold,
                    updated_at = CURRENT_TIMESTAMP;
            """, (budget.month, budget.monthly_limit, budget.alert_threshold))
            conn.commit()
            cursor.execute("SELECT id, updated_at FROM budgets WHERE month = ?;", (budget.month,))
            row = cursor.fetchone()
            if row:
                budget.id = row["id"]
            return budget

    # --- Categories Operations ---

    def get_all_categories(self) -> List[Category]:
        """Fetch all categories from the database."""
        categories: List[Category] = []
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM categories ORDER BY name ASC;")
            for row in cursor.fetchall():
                cat = Category(
                    category_id=row["id"],
                    name=row["name"],
                    icon=row["icon"],
                    color=row["color"],
                    budget_limit=row["budget_limit"]
                )
                categories.append(cat)
        return categories

    def add_category(self, category: Category) -> Category:
        """Insert a custom category."""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO categories (name, icon, color, budget_limit)
                VALUES (?, ?, ?, ?);
            """, (category.name, category.icon, category.color, category.budget_limit))
            conn.commit()
            category.id = cursor.lastrowid
            return category
