"""
PennyWise - Personal Expense Tracker
Module: routes/api.py
Flask REST API Blueprint communicating with the OOP ExpenseManager
Demonstrates:
- Clean Separation of Concerns: routes only parse HTTP requests and format HTTP responses;
  all domain validation, business calculations, and database logic reside strictly in OOP classes.
"""

from flask import Blueprint, request, jsonify, Response
from typing import Dict, Any
from datetime import datetime
import os

from models.expense_manager import ExpenseManager

api_bp = Blueprint("api", __name__, url_prefix="/api")

# Initialize shared singleton ExpenseManager
expense_manager = ExpenseManager()


@api_bp.route("/health", methods=["GET"])
def health_check():
    """Health check endpoint."""
    return jsonify({
        "status": "healthy",
        "app": "PennyWise",
        "version": "1.0.0",
        "architecture": "Python OOP + Flask + SQLite",
        "timestamp": datetime.now().isoformat()
    }), 200


@api_bp.route("/dashboard", methods=["GET"])
def get_dashboard():
    """
    Returns high-level statistics, spending trends, recent expenses,
    and category breakdowns for the dashboard.
    """
    try:
        month = request.args.get("month", None)
        summary = expense_manager.get_dashboard_summary(month=month)
        return jsonify({
            "success": True,
            "data": summary
        }), 200
    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500


@api_bp.route("/transactions", methods=["GET"])
def list_transactions():
    """
    List transactions with optional search, category filter, date ranges, and sorting.
    """
    try:
        search = request.args.get("search", None)
        category = request.args.get("category", None)
        start_date = request.args.get("start_date", None)
        end_date = request.args.get("end_date", None)
        sort_by = request.args.get("sort_by", "date")
        order = request.args.get("order", "DESC")

        transactions = expense_manager.list_expenses(
            search=search,
            category=category,
            start_date=start_date,
            end_date=end_date,
            sort_by=sort_by,
            order=order
        )

        return jsonify({
            "success": True,
            "count": len(transactions),
            "data": transactions
        }), 200
    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500


@api_bp.route("/transactions/<int:expense_id>", methods=["GET"])
def get_transaction(expense_id: int):
    """Retrieve details of a single transaction."""
    try:
        item = expense_manager.get_expense(expense_id)
        if not item:
            return jsonify({
                "success": False,
                "error": f"Transaction with ID {expense_id} not found."
            }), 404

        return jsonify({
            "success": True,
            "data": item
        }), 200
    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500


@api_bp.route("/transactions", methods=["POST"])
def create_transaction():
    """
    Create a new expense entry.
    All data is strictly validated by OOP domain classes.
    """
    try:
        payload = request.get_json() or {}
        title = payload.get("title")
        amount = payload.get("amount")
        category = payload.get("category", "Others")
        date = payload.get("date", datetime.now().strftime("%Y-%m-%d"))
        description = payload.get("description", "")

        if not title or amount is None:
            return jsonify({
                "success": False,
                "error": "Title and amount are required fields."
            }), 400

        # ExpenseManager creates and validates Expense OOP entity
        new_expense = expense_manager.create_expense(
            title=str(title),
            amount=float(amount),
            date=str(date),
            category=str(category),
            description=str(description)
        )

        return jsonify({
            "success": True,
            "message": "Expense recorded successfully.",
            "data": new_expense
        }), 201

    except ValueError as ve:
        # Domain validation errors from Expense/Transaction setters
        return jsonify({
            "success": False,
            "error": str(ve)
        }), 400
    except Exception as e:
        return jsonify({
            "success": False,
            "error": f"An unexpected error occurred: {str(e)}"
        }), 500


@api_bp.route("/transactions/<int:expense_id>", methods=["PUT"])
def update_transaction(expense_id: int):
    """Update an existing transaction."""
    try:
        payload = request.get_json() or {}
        title = payload.get("title")
        amount = payload.get("amount")
        category = payload.get("category", "Others")
        date = payload.get("date", datetime.now().strftime("%Y-%m-%d"))
        description = payload.get("description", "")

        if not title or amount is None:
            return jsonify({
                "success": False,
                "error": "Title and amount are required."
            }), 400

        updated = expense_manager.update_expense(
            expense_id=expense_id,
            title=str(title),
            amount=float(amount),
            date=str(date),
            category=str(category),
            description=str(description)
        )

        if not updated:
            return jsonify({
                "success": False,
                "error": f"Transaction with ID {expense_id} not found or no changes made."
            }), 404

        saved = expense_manager.get_expense(expense_id)
        return jsonify({
            "success": True,
            "message": "Expense updated successfully.",
            "data": saved
        }), 200

    except ValueError as ve:
        return jsonify({
            "success": False,
            "error": str(ve)
        }), 400
    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500


@api_bp.route("/transactions/<int:expense_id>", methods=["DELETE"])
def delete_transaction(expense_id: int):
    """Delete a transaction by ID."""
    try:
        deleted = expense_manager.delete_expense(expense_id)
        if not deleted:
            return jsonify({
                "success": False,
                "error": f"Transaction with ID {expense_id} not found."
            }), 404

        return jsonify({
            "success": True,
            "message": "Transaction deleted successfully.",
            "id": expense_id
        }), 200
    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500


@api_bp.route("/budget", methods=["GET"])
def get_budget():
    """Retrieve monthly budget info and utilization stats."""
    try:
        month = request.args.get("month", datetime.now().strftime("%Y-%m"))
        data = expense_manager.get_budget(month=month)
        return jsonify({
            "success": True,
            "data": data
        }), 200
    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500


@api_bp.route("/budget", methods=["POST"])
def set_budget():
    """Set or update monthly budget."""
    try:
        payload = request.get_json() or {}
        amount = payload.get("amount")
        month = payload.get("month", datetime.now().strftime("%Y-%m"))
        threshold = payload.get("alert_threshold", 80.0)

        if amount is None:
            return jsonify({
                "success": False,
                "error": "Budget amount is required."
            }), 400

        budget_data = expense_manager.set_budget(
            amount=float(amount),
            month=str(month),
            alert_threshold=float(threshold)
        )

        return jsonify({
            "success": True,
            "message": "Monthly budget updated successfully.",
            "data": budget_data
        }), 200

    except ValueError as ve:
        return jsonify({
            "success": False,
            "error": str(ve)
        }), 400
    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500


@api_bp.route("/categories", methods=["GET"])
def list_categories():
    """List all categories with metadata."""
    try:
        categories = expense_manager.get_categories()
        return jsonify({
            "success": True,
            "data": categories
        }), 200
    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500


@api_bp.route("/categories", methods=["POST"])
def add_category():
    """Create a new category."""
    try:
        payload = request.get_json() or {}
        name = payload.get("name")
        icon = payload.get("icon", "tag")
        color = payload.get("color", "#10B981")
        budget_limit = payload.get("budget_limit", 0.0)

        if not name:
            return jsonify({
                "success": False,
                "error": "Category name is required."
            }), 400

        cat = expense_manager.add_category(
            name=name,
            icon=icon,
            color=color,
            limit=float(budget_limit)
        )
        return jsonify({
            "success": True,
            "message": "Category created successfully.",
            "data": cat
        }), 201

    except ValueError as ve:
        return jsonify({
            "success": False,
            "error": str(ve)
        }), 400
    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500


@api_bp.route("/export/csv", methods=["GET"])
def export_csv():
    """Download transactions as a CSV spreadsheet."""
    try:
        csv_data = expense_manager.export_csv()
        filename = f"pennywise_expenses_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
        return Response(
            csv_data,
            mimetype="text/csv",
            headers={"Content-disposition": f"attachment; filename={filename}"}
        )
    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500


@api_bp.route("/demo-data", methods=["POST"])
def seed_demo_data():
    """Reset and seed fresh demo transactions."""
    try:
        expense_manager.reset_demo_data()
        return jsonify({
            "success": True,
            "message": "Demo sample transactions and budget reloaded successfully."
        }), 200
    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500


@api_bp.route("/demo-data", methods=["DELETE"])
def clear_all_data():
    """Clear all user data from database."""
    try:
        expense_manager.clear_all_data()
        return jsonify({
            "success": True,
            "message": "All expense and budget records cleared."
        }), 200
    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500
