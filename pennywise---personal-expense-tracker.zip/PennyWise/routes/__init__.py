"""
PennyWise - Personal Expense Tracker
Routes Package
"""

from .api import api_bp

__all__ = ['api_bp']
