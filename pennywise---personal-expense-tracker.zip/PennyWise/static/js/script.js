/**
 * PennyWise - Personal Expense Tracker
 * Frontend Client JavaScript (Vanilla ES6+)
 * Communicates with Python Flask REST API & renders Chart.js analytics
 */

const PennyWise = (() => {
  // --- State ---
  const state = {
    currentView: 'dashboard',
    selectedMonth: new Date().toISOString().slice(0, 7), // YYYY-MM
    categories: [],
    transactions: [],
    dashboardData: null,
    budgetData: null,
    deleteTargetId: null,
    charts: {
      monthlyTrend: null,
      categoryDoughnut: null,
      weeklyTrend: null,
      categoryBar: null
    }
  };

  // --- API Base URL ---
  const API_BASE = '/api';

  // --- Utility Functions ---
  const formatCurrency = (amt) => {
    const num = Number(amt) || 0;
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2
    }).format(num);
  };

  const formatDate = (dateStr) => {
    if (!dateStr) return '';
    try {
      const [y, m, d] = dateStr.split('-');
      const dt = new Date(y, m - 1, d);
      return dt.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
    } catch {
      return dateStr;
    }
  };

  const showToast = (message, type = 'success') => {
    const container = document.getElementById('toastContainer');
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    const icon = type === 'success' ? 'fa-check' : 'fa-circle-exclamation';
    toast.innerHTML = `<i class="fa-solid ${icon}"></i><span>${message}</span>`;

    container.appendChild(toast);
    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateX(20px)';
      toast.style.transition = 'all 0.3s ease';
      setTimeout(() => toast.remove(), 300);
    }, 3500);
  };

  // --- API Requests ---
  const api = {
    async get(endpoint, params = {}) {
      const url = new URL(API_BASE + endpoint, window.location.origin);
      Object.keys(params).forEach(k => {
        if (params[k] !== undefined && params[k] !== null && params[k] !== '') {
          url.searchParams.append(k, params[k]);
        }
      });
      const res = await fetch(url.toString());
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'API Request Failed');
      return data;
    },

    async post(endpoint, body = {}) {
      const res = await fetch(API_BASE + endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'API Request Failed');
      return data;
    },

    async put(endpoint, body = {}) {
      const res = await fetch(API_BASE + endpoint, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'API Request Failed');
      return data;
    },

    async delete(endpoint) {
      const res = await fetch(API_BASE + endpoint, { method: 'DELETE' });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'API Request Failed');
      return data;
    }
  };

  // --- View Navigation ---
  const initNavigation = () => {
    const navItems = document.querySelectorAll('.nav-item');
    navItems.forEach(item => {
      item.addEventListener('click', () => {
        const targetView = item.dataset.view;
        switchView(targetView);
      });
    });

    // Mobile sidebar toggles
    const mobileMenuBtn = document.getElementById('mobileMenuBtn');
    const sidebarCloseBtn = document.getElementById('sidebarCloseBtn');
    const sidebar = document.getElementById('sidebar');

    if (mobileMenuBtn && sidebar) {
      mobileMenuBtn.addEventListener('click', () => sidebar.classList.add('mobile-open'));
    }
    if (sidebarCloseBtn && sidebar) {
      sidebarCloseBtn.addEventListener('click', () => sidebar.classList.remove('mobile-open'));
    }

    // Month picker listener
    const monthPicker = document.getElementById('globalMonthPicker');
    if (monthPicker) {
      monthPicker.value = state.selectedMonth;
      monthPicker.addEventListener('change', (e) => {
        state.selectedMonth = e.target.value || new Date().toISOString().slice(0, 7);
        loadAllData();
      });
    }

    // Quick jump to all transactions from dashboard
    const btnViewAll = document.getElementById('btnViewAllTransactions');
    if (btnViewAll) {
      btnViewAll.addEventListener('click', () => switchView('transactions'));
    }

    const btnAdjustBudget = document.getElementById('btnQuickAdjustBudget');
    if (btnAdjustBudget) {
      btnAdjustBudget.addEventListener('click', () => switchView('budget'));
    }
  };

  const switchView = (viewName) => {
    state.currentView = viewName;

    // Update active nav button
    document.querySelectorAll('.nav-item').forEach(btn => {
      btn.classList.toggle('active', btn.dataset.view === viewName);
    });

    // Update active view section
    document.querySelectorAll('.view-section').forEach(sec => {
      sec.classList.remove('active');
    });
    const targetSection = document.getElementById(`view-${viewName}`);
    if (targetSection) targetSection.classList.add('active');

    // Update Topbar Title
    const titles = {
      dashboard: { title: 'Dashboard Overview', sub: 'Real-time expenditure tracking and budget intelligence' },
      transactions: { title: 'Transactions Management', sub: 'Inspect, filter, search, and manage all your expenses' },
      budget: { title: 'Budget Management', sub: 'Configure spending targets and manage utilization thresholds' },
      analytics: { title: 'Analytics & Financial Trends', sub: 'Deep-dive into multi-month trends and category distributions' },
      categories: { title: 'Categories Overview', sub: 'Explore spending classifications and target allocations' },
      'oop-architecture': { title: 'Python OOP Architecture', sub: 'Academic design pattern inspection, UML hierarchy, and concepts' }
    };
    const t = titles[viewName] || titles.dashboard;
    document.getElementById('pageTitle').textContent = t.title;
    document.getElementById('pageSubtitle').textContent = t.sub;

    // Close mobile sidebar if open
    document.getElementById('sidebar')?.classList.remove('mobile-open');

    // Re-render specific view components if required
    if (viewName === 'analytics') renderAnalyticsCharts();
    if (viewName === 'categories') renderCategoriesView();
    if (viewName === 'budget') renderBudgetView();
    if (viewName === 'transactions') loadTransactions();
  };

  // --- Category Badges & Helpers ---
  const getCategoryMeta = (catName) => {
    const found = state.categories.find(c => c.name.toLowerCase() === (catName || '').toLowerCase());
    return found || {
      name: catName || 'Others',
      icon: 'tag',
      color: '#6B7280'
    };
  };

  const renderCategoryPill = (catName) => {
    const meta = getCategoryMeta(catName);
    return `<span class="category-tag" style="background-color: ${meta.color}22; color: ${meta.color}; border: 1px solid ${meta.color}55;">
      <i class="fa-solid fa-${meta.icon}"></i> ${meta.name}
    </span>`;
  };

  // --- Data Loading ---
  const loadAllData = async () => {
    try {
      await loadCategories();
      await loadDashboard();
      await loadBudget();
      if (state.currentView === 'transactions') await loadTransactions();
    } catch (err) {
      console.error('Error loading PennyWise data:', err);
      showToast(err.message, 'error');
    }
  };

  const loadCategories = async () => {
    const res = await api.get('/categories');
    state.categories = res.data || [];

    // Populate filter dropdowns
    const filterSelect = document.getElementById('txCategoryFilter');
    const formSelect = document.getElementById('formCategory');

    if (filterSelect) {
      const currentVal = filterSelect.value;
      filterSelect.innerHTML = '<option value="all">All Categories</option>' +
        state.categories.map(c => `<option value="${c.name}">${c.name}</option>`).join('');
      filterSelect.value = currentVal || 'all';
    }

    if (formSelect) {
      formSelect.innerHTML = state.categories.map(c => 
        `<option value="${c.name}">${c.name}</option>`
      ).join('');
    }
  };

  const loadDashboard = async () => {
    const res = await api.get('/dashboard', { month: state.selectedMonth });
    state.dashboardData = res.data;
    renderDashboardUI(res.data);
  };

  const renderDashboardUI = (data) => {
    if (!data) return;

    // Stat Cards
    document.getElementById('statTotalExpenses').textContent = formatCurrency(data.total_expenses);
    document.getElementById('statTxCount').textContent = `${data.transaction_count} recorded`;
    document.getElementById('navTxCount').textContent = data.transaction_count;

    document.getElementById('statMonthlySpending').textContent = formatCurrency(data.monthly_expenses);
    document.getElementById('statMonthLabel').textContent = data.current_month;
    document.getElementById('statDailyAvg').textContent = `Avg ${formatCurrency(data.average_daily_spending)}/day`;

    // Budget card
    const b = data.budget;
    document.getElementById('statRemainingBudget').textContent = formatCurrency(b.remaining);
    document.getElementById('statBudgetLimit').textContent = `of ${formatCurrency(b.monthly_limit)} limit`;
    document.getElementById('statBudgetStatus').textContent = b.status === 'safe' ? 'On Track' : (b.status === 'warning' ? 'Warning' : 'Exceeded');
    document.getElementById('statBudgetStatus').className = `badge ${b.status === 'safe' ? 'badge-emerald' : (b.status === 'warning' ? 'badge-warning' : 'badge-danger')}`;

    // Utilization Progress Bar
    const util = Math.min(100, Math.max(0, b.utilization_percentage));
    document.getElementById('statUtilization').textContent = `${b.utilization_percentage}%`;
    const progressBar = document.getElementById('statProgressBar');
    progressBar.style.width = `${util}%`;
    progressBar.className = `progress-bar-fill ${b.status === 'warning' ? 'warning' : (b.status === 'exceeded' ? 'danger' : '')}`;

    // Alert Banner
    const alertContainer = document.getElementById('budgetAlertContainer');
    const alertBox = document.getElementById('budgetAlertBox');
    const alertHeading = document.getElementById('alertHeading');
    const alertMessage = document.getElementById('alertMessage');

    if (b.warning_message) {
      alertContainer.classList.remove('hidden');
      alertBox.className = `alert ${b.status === 'exceeded' ? 'alert-danger' : 'alert-warning'}`;
      alertHeading.textContent = b.status === 'exceeded' ? 'Budget Exceeded!' : 'Budget Warning Alert';
      alertMessage.textContent = b.warning_message;
    } else {
      alertContainer.classList.add('hidden');
    }

    // Recent Transactions Table
    renderRecentTransactions(data.recent_transactions);

    // Category Ranking List
    renderCategoryRankings(data.category_breakdown);

    // Charts
    renderMonthlyTrendChart(data.monthly_trends);
    renderCategoryDoughnutChart(data.category_breakdown);
  };

  const renderRecentTransactions = (items) => {
    const tbody = document.getElementById('recentTransactionsBody');
    const emptyState = document.getElementById('recentEmptyState');

    if (!items || items.length === 0) {
      tbody.innerHTML = '';
      emptyState.classList.remove('hidden');
      return;
    }

    emptyState.classList.add('hidden');
    tbody.innerHTML = items.map(tx => `
      <tr>
        <td>
          <div class="tx-title-cell">
            <span class="tx-title-name">${escapeHtml(tx.title)}</span>
            <span class="tx-title-desc">${escapeHtml(tx.description || 'No notes')}</span>
          </div>
        </td>
        <td>${renderCategoryPill(tx.category)}</td>
        <td>${formatDate(tx.date)}</td>
        <td class="text-right tx-amount text-emerald">${formatCurrency(tx.amount)}</td>
        <td class="text-center">
          <div class="table-actions-cell">
            <button class="btn-table-action" onclick="PennyWise.openEditModal(${tx.id})" title="Edit Expense">
              <i class="fa-solid fa-pen-to-square"></i>
            </button>
            <button class="btn-table-action delete" onclick="PennyWise.openDeleteModal(${tx.id}, '${escapeQuote(tx.title)}')" title="Delete Expense">
              <i class="fa-solid fa-trash-can"></i>
            </button>
          </div>
        </td>
      </tr>
    `).join('');
  };

  const renderCategoryRankings = (categories) => {
    const list = document.getElementById('categoryRankingList');
    if (!categories || categories.length === 0) {
      list.innerHTML = '<div class="empty-state p-3"><p>No expenses for this month.</p></div>';
      return;
    }

    list.innerHTML = categories.map(c => `
      <div class="category-row">
        <div class="category-row-left">
          <div class="cat-icon-bullet" style="background-color: ${c.color}">
            <i class="fa-solid fa-${c.icon}"></i>
          </div>
          <div>
            <div class="cat-name">${escapeHtml(c.category)}</div>
            <div class="cat-tx-count">${c.count} transactions</div>
          </div>
        </div>
        <div class="category-row-right">
          <div class="cat-amt">${formatCurrency(c.amount)}</div>
          <div class="cat-pct">${c.percentage}% of total</div>
        </div>
      </div>
    `).join('');
  };

  // --- Transactions Management View ---
  const loadTransactions = async () => {
    const search = document.getElementById('txSearchInput')?.value || '';
    const category = document.getElementById('txCategoryFilter')?.value || 'all';
    const sortVal = document.getElementById('txSortBy')?.value || 'date-DESC';
    const [sort_by, order] = sortVal.split('-');

    try {
      const res = await api.get('/transactions', { search, category, sort_by, order });
      state.transactions = res.data || [];
      renderTransactionsTable(state.transactions);
    } catch (err) {
      showToast(err.message, 'error');
    }
  };

  const renderTransactionsTable = (items) => {
    const tbody = document.getElementById('allTransactionsBody');
    const emptyState = document.getElementById('txEmptyState');
    const countSummary = document.getElementById('txCountSummary');

    countSummary.textContent = `Showing ${items.length} transaction${items.length === 1 ? '' : 's'}`;

    if (!items || items.length === 0) {
      tbody.innerHTML = '';
      emptyState.classList.remove('hidden');
      return;
    }

    emptyState.classList.add('hidden');
    tbody.innerHTML = items.map(tx => `
      <tr>
        <td>
          <div class="tx-title-cell">
            <span class="tx-title-name">${escapeHtml(tx.title)}</span>
            <span class="tx-title-desc">${escapeHtml(tx.description || 'No notes')}</span>
          </div>
        </td>
        <td>${renderCategoryPill(tx.category)}</td>
        <td>${formatDate(tx.date)}</td>
        <td class="text-right tx-amount text-emerald">${formatCurrency(tx.amount)}</td>
        <td class="text-center">
          <div class="table-actions-cell">
            <button class="btn-table-action" onclick="PennyWise.openEditModal(${tx.id})" title="Edit Expense">
              <i class="fa-solid fa-pen-to-square"></i>
            </button>
            <button class="btn-table-action delete" onclick="PennyWise.openDeleteModal(${tx.id}, '${escapeQuote(tx.title)}')" title="Delete Expense">
              <i class="fa-solid fa-trash-can"></i>
            </button>
          </div>
        </td>
      </tr>
    `).join('');
  };

  const initTransactionFilters = () => {
    const searchInput = document.getElementById('txSearchInput');
    const catFilter = document.getElementById('txCategoryFilter');
    const sortBy = document.getElementById('txSortBy');
    const btnReset = document.getElementById('btnResetFilters');

    let debounceTimer;
    if (searchInput) {
      searchInput.addEventListener('input', () => {
        clearTimeout(debounceTimer);
        debounceTimer = setTimeout(loadTransactions, 250);
      });
    }

    if (catFilter) catFilter.addEventListener('change', loadTransactions);
    if (sortBy) sortBy.addEventListener('change', loadTransactions);

    if (btnReset) {
      btnReset.addEventListener('click', () => {
        if (searchInput) searchInput.value = '';
        if (catFilter) catFilter.value = 'all';
        if (sortBy) sortBy.value = 'date-DESC';
        loadTransactions();
      });
    }

    const btnClearAll = document.getElementById('btnClearAllData');
    if (btnClearAll) {
      btnClearAll.addEventListener('click', async () => {
        if (confirm('Are you sure you want to clear ALL transactions and reset data?')) {
          await api.delete('/demo-data');
          showToast('All transaction records cleared.', 'success');
          loadAllData();
        }
      });
    }
  };

  // --- Budget Management View ---
  const loadBudget = async () => {
    const res = await api.get('/budget', { month: state.selectedMonth });
    state.budgetData = res.data;
    renderBudgetView();
  };

  const renderBudgetView = () => {
    const b = state.budgetData;
    if (!b) return;

    document.getElementById('budgetPageLimit').textContent = formatCurrency(b.monthly_limit);
    document.getElementById('budgetPageSpent').textContent = formatCurrency(b.total_spent);
    document.getElementById('budgetPageRemaining').textContent = formatCurrency(b.remaining);
    document.getElementById('budgetPagePercent').textContent = `${b.utilization_percentage}%`;

    const statusBadge = document.getElementById('budgetPageStatusBadge');
    statusBadge.textContent = b.status.toUpperCase();
    statusBadge.className = `badge ${b.status === 'safe' ? 'badge-emerald' : (b.status === 'warning' ? 'badge-warning' : 'badge-danger')}`;

    const progressBar = document.getElementById('budgetPageProgressBar');
    progressBar.style.width = `${Math.min(100, Math.max(0, b.utilization_percentage))}%`;
    progressBar.className = `progress-bar-fill ${b.status === 'warning' ? 'warning' : (b.status === 'exceeded' ? 'danger' : '')}`;

    document.getElementById('thresholdMarker').textContent = `Warning at ${b.alert_threshold}%`;

    // Advisory Card
    const advisory = document.getElementById('budgetAdvisoryCard');
    const advisoryIcon = document.getElementById('advisoryIcon');
    const advisoryTitle = document.getElementById('advisoryTitle');
    const advisoryDetail = document.getElementById('advisoryDetail');

    advisory.className = `advisory-card ${b.status}`;
    if (b.status === 'exceeded') {
      advisoryIcon.className = 'fa-solid fa-triangle-exclamation text-danger';
      advisoryTitle.textContent = 'Budget Exceeded Alert';
      advisoryDetail.textContent = `You have spent ${formatCurrency(Math.abs(b.remaining))} over your target limit. Immediate attention recommended.`;
    } else if (b.status === 'warning') {
      advisoryIcon.className = 'fa-solid fa-circle-exclamation text-amber';
      advisoryTitle.textContent = 'High Spending Warning';
      advisoryDetail.textContent = `You have utilized ${b.utilization_percentage}% of your limit. Only ${formatCurrency(b.remaining)} left for the rest of this month.`;
    } else {
      advisoryIcon.className = 'fa-solid fa-shield-halved text-emerald';
      advisoryTitle.textContent = 'Budget Health: Excellent';
      advisoryDetail.textContent = `You have spent ${b.utilization_percentage}% of your budget. You are comfortably within your spending targets.`;
    }

    // Set input values in form
    const amountInput = document.getElementById('budgetInputAmount');
    const thresholdInput = document.getElementById('budgetInputThreshold');
    const thresholdDisplay = document.getElementById('thresholdValueDisplay');

    if (amountInput) amountInput.value = b.monthly_limit;
    if (thresholdInput) {
      thresholdInput.value = b.alert_threshold;
      thresholdDisplay.textContent = `${b.alert_threshold}%`;
    }
  };

  const initBudgetForm = () => {
    const form = document.getElementById('budgetSettingsForm');
    const thresholdInput = document.getElementById('budgetInputThreshold');
    const thresholdDisplay = document.getElementById('thresholdValueDisplay');

    if (thresholdInput && thresholdDisplay) {
      thresholdInput.addEventListener('input', (e) => {
        thresholdDisplay.textContent = `${e.target.value}%`;
      });
    }

    // Preset buttons
    document.querySelectorAll('.btn-preset').forEach(btn => {
      btn.addEventListener('click', () => {
        const val = btn.dataset.val;
        const input = document.getElementById('budgetInputAmount');
        if (input) input.value = val;
      });
    });

    if (form) {
      form.addEventListener('submit', async (e) => {
        e.preventDefault();
        const amount = document.getElementById('budgetInputAmount').value;
        const alert_threshold = document.getElementById('budgetInputThreshold').value;

        try {
          const res = await api.post('/budget', {
            amount: parseFloat(amount),
            month: state.selectedMonth,
            alert_threshold: parseFloat(alert_threshold)
          });
          state.budgetData = res.data;
          showToast('Budget preferences saved successfully!', 'success');
          loadDashboard();
          renderBudgetView();
        } catch (err) {
          showToast(err.message, 'error');
        }
      });
    }
  };

  // --- Categories View ---
  const renderCategoriesView = () => {
    const grid = document.getElementById('categoriesGrid');
    if (!grid) return;

    const breakdown = state.dashboardData?.category_breakdown || [];
    const breakdownMap = {};
    breakdown.forEach(b => { breakdownMap[b.category] = b; });

    grid.innerHTML = state.categories.map(cat => {
      const bData = breakdownMap[cat.name] || { amount: 0, count: 0, percentage: 0 };
      return `
        <div class="category-card">
          <div class="cat-card-header">
            <div class="cat-card-brand">
              <div class="cat-card-icon" style="background-color: ${cat.color}">
                <i class="fa-solid fa-${cat.icon}"></i>
              </div>
              <div>
                <h4 class="cat-card-title">${escapeHtml(cat.name)}</h4>
                <span class="badge badge-subtle">${bData.count} entries</span>
              </div>
            </div>
            <span class="pill-badge">${bData.percentage}% of month</span>
          </div>
          <div class="cat-card-body">
            <div>
              <div class="cat-card-metric-label">Monthly Spent</div>
              <div class="cat-card-metric-val" style="color: ${cat.color}">
                ${formatCurrency(bData.amount)}
              </div>
            </div>
            ${cat.budget_limit > 0 ? `
              <div class="text-right">
                <div class="cat-card-metric-label">Target Ceiling</div>
                <div class="cat-card-metric-val text-muted">${formatCurrency(cat.budget_limit)}</div>
              </div>
            ` : ''}
          </div>
        </div>
      `;
    }).join('');
  };

  // --- Analytics View & Charts ---
  const renderAnalyticsCharts = () => {
    const data = state.dashboardData;
    if (!data) return;

    document.getElementById('analyticsAvgDaily').textContent = formatCurrency(data.average_daily_spending);
    document.getElementById('analyticsTxCount').textContent = data.monthly_transaction_count;

    if (data.top_category) {
      document.getElementById('analyticsTopCategory').textContent = data.top_category.category;
      document.getElementById('analyticsTopCategoryAmount').textContent = `${formatCurrency(data.top_category.amount)} this month`;
    } else {
      document.getElementById('analyticsTopCategory').textContent = 'None';
      document.getElementById('analyticsTopCategoryAmount').textContent = '$0.00 this month';
    }

    renderWeeklyTrendChart(data.weekly_trends);
    renderCategoryBarChart(data.category_breakdown);
  };

  // --- Chart.js Rendering Functions ---
  const renderMonthlyTrendChart = (trends) => {
    const ctx = document.getElementById('monthlyTrendChart')?.getContext('2d');
    if (!ctx || !trends) return;

    if (state.charts.monthlyTrend) state.charts.monthlyTrend.destroy();

    const gradient = ctx.createLinearGradient(0, 0, 0, 260);
    gradient.addColorStop(0, 'rgba(16, 185, 129, 0.35)');
    gradient.addColorStop(1, 'rgba(16, 185, 129, 0.0)');

    state.charts.monthlyTrend = new Chart(ctx, {
      type: 'line',
      data: {
        labels: trends.labels,
        datasets: [{
          label: 'Total Expenses ($)',
          data: trends.values,
          borderColor: '#10b981',
          borderWidth: 3,
          backgroundColor: gradient,
          fill: true,
          tension: 0.35,
          pointBackgroundColor: '#10b981',
          pointBorderColor: '#ffffff',
          pointBorderWidth: 2,
          pointRadius: 4,
          pointHoverRadius: 6
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false },
          tooltip: {
            backgroundColor: '#172237',
            titleColor: '#f8fafc',
            bodyColor: '#10b981',
            borderColor: '#243247',
            borderWidth: 1,
            padding: 10,
            callbacks: {
              label: (context) => ` ${formatCurrency(context.raw)}`
            }
          }
        },
        scales: {
          x: {
            grid: { color: 'rgba(255, 255, 255, 0.05)' },
            ticks: { color: '#94a3b8', font: { family: 'Plus Jakarta Sans', size: 11 } }
          },
          y: {
            grid: { color: 'rgba(255, 255, 255, 0.05)' },
            ticks: {
              color: '#94a3b8',
              font: { family: 'Plus Jakarta Sans', size: 11 },
              callback: (val) => `$${val}`
            }
          }
        }
      }
    });
  };

  const renderCategoryDoughnutChart = (categories) => {
    const ctx = document.getElementById('categoryChart')?.getContext('2d');
    if (!ctx) return;

    if (state.charts.categoryDoughnut) state.charts.categoryDoughnut.destroy();

    if (!categories || categories.length === 0) {
      // Empty placeholder
      state.charts.categoryDoughnut = new Chart(ctx, {
        type: 'doughnut',
        data: {
          labels: ['No Expenses'],
          datasets: [{ data: [1], backgroundColor: ['#243247'] }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: { legend: { display: false } }
        }
      });
      return;
    }

    state.charts.categoryDoughnut = new Chart(ctx, {
      type: 'doughnut',
      data: {
        labels: categories.map(c => c.category),
        datasets: [{
          data: categories.map(c => c.amount),
          backgroundColor: categories.map(c => c.color),
          borderColor: '#121a2b',
          borderWidth: 3,
          hoverOffset: 8
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        cutout: '70%',
        plugins: {
          legend: {
            position: 'bottom',
            labels: {
              color: '#cbd5e1',
              font: { family: 'Plus Jakarta Sans', size: 11 },
              padding: 12,
              usePointStyle: true,
              pointStyle: 'circle'
            }
          },
          tooltip: {
            backgroundColor: '#172237',
            titleColor: '#f8fafc',
            bodyColor: '#cbd5e1',
            borderColor: '#243247',
            borderWidth: 1,
            callbacks: {
              label: (context) => ` ${context.label}: ${formatCurrency(context.raw)}`
            }
          }
        }
      }
    });
  };

  const renderWeeklyTrendChart = (weekly) => {
    const ctx = document.getElementById('weeklyTrendChart')?.getContext('2d');
    if (!ctx || !weekly) return;

    if (state.charts.weeklyTrend) state.charts.weeklyTrend.destroy();

    state.charts.weeklyTrend = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: weekly.labels,
        datasets: [{
          label: 'Daily Spending',
          data: weekly.values,
          backgroundColor: '#3b82f6',
          borderRadius: 6,
          hoverBackgroundColor: '#60a5fa'
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false },
          tooltip: {
            backgroundColor: '#172237',
            callbacks: {
              label: (context) => ` Spent: ${formatCurrency(context.raw)}`
            }
          }
        },
        scales: {
          x: {
            grid: { display: false },
            ticks: { color: '#94a3b8', font: { size: 11 } }
          },
          y: {
            grid: { color: 'rgba(255, 255, 255, 0.05)' },
            ticks: {
              color: '#94a3b8',
              callback: (val) => `$${val}`
            }
          }
        }
      }
    });
  };

  const renderCategoryBarChart = (categories) => {
    const ctx = document.getElementById('analyticsCategoryBarChart')?.getContext('2d');
    if (!ctx) return;

    if (state.charts.categoryBar) state.charts.categoryBar.destroy();

    const items = categories || [];
    state.charts.categoryBar = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: items.map(c => c.category),
        datasets: [{
          label: 'Expenditure',
          data: items.map(c => c.amount),
          backgroundColor: items.map(c => c.color),
          borderRadius: 6
        }]
      },
      options: {
        indexAxis: 'y',
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false },
          tooltip: {
            backgroundColor: '#172237',
            callbacks: {
              label: (context) => ` ${formatCurrency(context.raw)}`
            }
          }
        },
        scales: {
          x: {
            grid: { color: 'rgba(255, 255, 255, 0.05)' },
            ticks: {
              color: '#94a3b8',
              callback: (val) => `$${val}`
            }
          },
          y: {
            grid: { display: false },
            ticks: { color: '#94a3b8' }
          }
        }
      }
    });
  };

  // --- Modals Management ---
  const openAddModal = () => {
    document.getElementById('expenseModalTitle').textContent = 'Add New Expense';
    document.getElementById('formExpenseId').value = '';
    document.getElementById('formTitle').value = '';
    document.getElementById('formAmount').value = '';
    document.getElementById('formDate').value = new Date().toISOString().slice(0, 10);
    document.getElementById('formDescription').value = '';
    document.getElementById('formCategory').value = 'Food';

    const modal = document.getElementById('expenseModal');
    modal.classList.add('active');
    document.getElementById('formTitle').focus();
  };

  const openEditModal = async (expenseId) => {
    try {
      const res = await api.get(`/transactions/${expenseId}`);
      const tx = res.data;

      document.getElementById('expenseModalTitle').textContent = 'Edit Expense';
      document.getElementById('formExpenseId').value = tx.id;
      document.getElementById('formTitle').value = tx.title;
      document.getElementById('formAmount').value = tx.amount;
      document.getElementById('formDate').value = tx.date;
      document.getElementById('formDescription').value = tx.description || '';
      document.getElementById('formCategory').value = tx.category;

      const modal = document.getElementById('expenseModal');
      modal.classList.add('active');
      document.getElementById('formTitle').focus();
    } catch (err) {
      showToast(err.message, 'error');
    }
  };

  const closeExpenseModal = () => {
    document.getElementById('expenseModal').classList.remove('active');
  };

  const initExpenseModalForm = () => {
    const btnOpen = document.getElementById('btnOpenAddModal');
    const btnClose = document.getElementById('btnCloseExpenseModal');
    const btnCancel = document.getElementById('btnCancelExpenseModal');
    const form = document.getElementById('expenseForm');

    if (btnOpen) btnOpen.addEventListener('click', openAddModal);
    if (btnClose) btnClose.addEventListener('click', closeExpenseModal);
    if (btnCancel) btnCancel.addEventListener('click', closeExpenseModal);

    if (form) {
      form.addEventListener('submit', async (e) => {
        e.preventDefault();
        const id = document.getElementById('formExpenseId').value;
        const title = document.getElementById('formTitle').value.trim();
        const amount = parseFloat(document.getElementById('formAmount').value);
        const date = document.getElementById('formDate').value;
        const category = document.getElementById('formCategory').value;
        const description = document.getElementById('formDescription').value.trim();

        if (!title || isNaN(amount) || amount <= 0 || !date) {
          showToast('Please fill all required fields with valid values.', 'error');
          return;
        }

        try {
          if (id) {
            // Edit existing
            await api.put(`/transactions/${id}`, { title, amount, date, category, description });
            showToast('Expense updated successfully!', 'success');
          } else {
            // Create new
            await api.post('/transactions', { title, amount, date, category, description });
            showToast('Expense recorded successfully!', 'success');
          }
          closeExpenseModal();
          loadAllData();
        } catch (err) {
          showToast(err.message, 'error');
        }
      });
    }
  };

  // Delete Modal
  const openDeleteModal = (id, title) => {
    state.deleteTargetId = id;
    document.getElementById('deleteTargetTitle').textContent = `"${title}"`;
    document.getElementById('deleteConfirmModal').classList.add('active');
  };

  const closeDeleteModal = () => {
    state.deleteTargetId = null;
    document.getElementById('deleteConfirmModal').classList.remove('active');
  };

  const initDeleteModal = () => {
    const btnClose = document.getElementById('btnCloseDeleteModal');
    const btnCancel = document.getElementById('btnCancelDelete');
    const btnConfirm = document.getElementById('btnConfirmDelete');

    if (btnClose) btnClose.addEventListener('click', closeDeleteModal);
    if (btnCancel) btnCancel.addEventListener('click', closeDeleteModal);

    if (btnConfirm) {
      btnConfirm.addEventListener('click', async () => {
        if (!state.deleteTargetId) return;
        try {
          await api.delete(`/transactions/${state.deleteTargetId}`);
          showToast('Expense deleted successfully.', 'success');
          closeDeleteModal();
          loadAllData();
        } catch (err) {
          showToast(err.message, 'error');
        }
      });
    }
  };

  // Custom Category Modal
  const initCategoryModal = () => {
    const btnOpen = document.getElementById('btnOpenAddCategoryModal');
    const btnClose = document.getElementById('btnCloseCategoryModal');
    const btnCancel = document.getElementById('btnCancelCategoryModal');
    const form = document.getElementById('categoryForm');

    if (btnOpen) {
      btnOpen.addEventListener('click', () => {
        document.getElementById('categoryModal').classList.add('active');
      });
    }

    const closeCatModal = () => {
      document.getElementById('categoryModal').classList.remove('active');
    };

    if (btnClose) btnClose.addEventListener('click', closeCatModal);
    if (btnCancel) btnCancel.addEventListener('click', closeCatModal);

    if (form) {
      form.addEventListener('submit', async (e) => {
        e.preventDefault();
        const name = document.getElementById('catFormName').value.trim();
        const color = document.getElementById('catFormColor').value;
        const budget_limit = parseFloat(document.getElementById('catFormLimit').value) || 0;

        if (!name) return;

        try {
          await api.post('/categories', { name, color, budget_limit });
          showToast(`Category "${name}" created!`, 'success');
          closeCatModal();
          form.reset();
          loadAllData();
        } catch (err) {
          showToast(err.message, 'error');
        }
      });
    }
  };

  // Seed Demo Data Button in Sidebar
  const initSeedDemo = () => {
    const btn = document.getElementById('btnSeedDemo');
    if (btn) {
      btn.addEventListener('click', async () => {
        try {
          btn.disabled = true;
          btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Loading...';
          await api.post('/demo-data');
          showToast('Sample expenses and budget reloaded!', 'success');
          await loadAllData();
        } catch (err) {
          showToast(err.message, 'error');
        } finally {
          btn.disabled = false;
          btn.innerHTML = '<i class="fa-solid fa-rotate-left"></i> Reload Demo Data';
        }
      });
    }
  };

  // Escape HTML helper
  const escapeHtml = (str) => {
    if (!str) return '';
    return str.replace(/[&<>'"]/g, tag => ({
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      "'": '&#39;',
      '"': '&quot;'
    }[tag] || tag));
  };

  const escapeQuote = (str) => {
    if (!str) return '';
    return str.replace(/'/g, "\\'");
  };

  // --- Initialization ---
  const init = () => {
    initNavigation();
    initTransactionFilters();
    initExpenseModalForm();
    initDeleteModal();
    initBudgetForm();
    initCategoryModal();
    initSeedDemo();
    loadAllData();
  };

  // Public API
  return {
    init,
    openAddModal,
    openEditModal,
    openDeleteModal
  };
})();

// Launch application on DOM ready
document.addEventListener('DOMContentLoaded', PennyWise.init);
