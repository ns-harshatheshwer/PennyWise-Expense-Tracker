"""
PennyWise - Personal Expense Tracker
Module: models/transaction.py
Demonstrates:
- Abstraction: BaseTransaction abstract base class with @abstractmethod
- Encapsulation: Protected attributes with getters/setters and data validation
"""

from abc import ABC, abstractmethod
from datetime import datetime
from typing import Dict, Any, Optional
import re


class BaseTransaction(ABC):
    """
    Abstract Base Class representing a financial transaction.
    Enforces the contract that all transaction types must fulfill.
    """

    @abstractmethod
    def to_dict(self) -> Dict[str, Any]:
        """Convert transaction instance to a dictionary representation."""
        pass

    @abstractmethod
    def calculate_monthly_impact(self, target_month: Optional[str] = None) -> float:
        """Calculate the financial impact for a given month (YYYY-MM)."""
        pass

    @abstractmethod
    def summary(self) -> str:
        """Return a human-readable summary string of the transaction."""
        pass

    @abstractmethod
    def validate(self) -> bool:
        """Validate transaction fields; raises ValueError if invalid."""
        pass


class Transaction(BaseTransaction):
    """
    Concrete Transaction class implementing BaseTransaction.
    Demonstrates Encapsulation with private/protected attributes and validated properties.
    """

    def __init__(
        self,
        title: str,
        amount: float,
        date: str,
        description: str = "",
        transaction_id: Optional[int] = None,
        created_at: Optional[str] = None
    ):
        self._id: Optional[int] = transaction_id
        self._title: str = ""
        self._amount: float = 0.0
        self._date: str = ""
        self._description: str = description.strip() if description else ""
        self._created_at: str = created_at or datetime.now().isoformat()

        # Utilize encapsulated property setters with validation
        self.title = title
        self.amount = amount
        self.date = date

    # --- Encapsulation: Getters and Setters with Validation ---

    @property
    def id(self) -> Optional[int]:
        """Getter for transaction ID."""
        return self._id

    @id.setter
    def id(self, value: int) -> None:
        """Setter for transaction ID (cannot be set if already assigned)."""
        if self._id is not None and self._id != value:
            raise ValueError("Transaction ID cannot be reassigned.")
        self._id = int(value)

    @property
    def title(self) -> str:
        """Getter for title/name."""
        return self._title

    @title.setter
    def title(self, value: str) -> None:
        """Setter for title with validation."""
        if not value or not isinstance(value, str):
            raise ValueError("Transaction title must be a non-empty string.")
        cleaned = value.strip()
        if len(cleaned) < 2:
            raise ValueError("Transaction title must be at least 2 characters long.")
        if len(cleaned) > 100:
            raise ValueError("Transaction title must not exceed 100 characters.")
        self._title = cleaned

    @property
    def amount(self) -> float:
        """Getter for amount."""
        return self._amount

    @amount.setter
    def amount(self, value: Any) -> None:
        """Setter for amount with validation."""
        try:
            val = float(value)
        except (ValueError, TypeError):
            raise ValueError("Amount must be a valid number.")

        if val <= 0:
            raise ValueError("Amount must be strictly greater than zero.")
        # Round to 2 decimal places for financial accuracy
        self._amount = round(val, 2)

    @property
    def date(self) -> str:
        """Getter for transaction date in YYYY-MM-DD format."""
        return self._date

    @date.setter
    def date(self, value: str) -> None:
        """Setter for date with validation."""
        if not value or not isinstance(value, str):
            raise ValueError("Date must be provided as a string in YYYY-MM-DD format.")
        
        # Verify YYYY-MM-DD format
        date_pattern = r"^\d{4}-\d{2}-\d{2}$"
        if not re.match(date_pattern, value.strip()):
            raise ValueError("Date format must be strictly YYYY-MM-DD (e.g. 2026-11-03).")
        
        try:
            datetime.strptime(value.strip(), "%Y-%m-%d")
        except ValueError:
            raise ValueError("Invalid calendar date specified.")

        self._date = value.strip()

    @property
    def description(self) -> str:
        """Getter for description/notes."""
        return self._description

    @description.setter
    def description(self, value: str) -> None:
        """Setter for description."""
        self._description = value.strip() if value else ""

    @property
    def created_at(self) -> str:
        """Getter for creation timestamp."""
        return self._created_at

    # --- Concrete Implementations of Abstract Methods ---

    def validate(self) -> bool:
        """Check whether the transaction data is valid."""
        return bool(self._title and self._amount > 0 and self._date)

    def calculate_monthly_impact(self, target_month: Optional[str] = None) -> float:
        """
        Calculates impact for a specific month (YYYY-MM).
        If target_month is provided and matches transaction month, returns amount, else 0.0.
        """
        if not target_month:
            return self._amount
        tx_month = self._date[:7]  # Extracts 'YYYY-MM'
        return self._amount if tx_month == target_month else 0.0

    def summary(self) -> str:
        """Polymorphic summary representation."""
        return f"[{self._date}] {self._title}: ${self._amount:.2f}"

    def to_dict(self) -> Dict[str, Any]:
        """Convert to JSON-serializable dictionary."""
        return {
            "id": self._id,
            "title": self._title,
            "amount": self._amount,
            "date": self._date,
            "description": self._description,
            "created_at": self._created_at,
            "type": "standard"
        }

    def __str__(self) -> str:
        return self.summary()

    def __repr__(self) -> str:
        return f"<Transaction id={self._id} title='{self._title}' amount={self._amount}>"
