"""
PennyWise - Personal Expense Tracker
Models Package
Demonstrates Object-Oriented Programming (OOP) in Python:
- Abstraction: BaseTransaction abstract class with ABC
- Encapsulation: Protected attributes and validated properties
- Inheritance: Expense and RecurringExpense inheriting from Transaction
- Polymorphism: Overridden methods (to_dict, summary, calculate_monthly_impact)
- Composition: ExpenseManager composing DatabaseManager, Budget, Categories, and Expenses
"""

from .transaction import BaseTransaction, Transaction
from .expense import Expense, RecurringExpense
from .category import Category
from .budget import Budget
from .expense_manager import ExpenseManager

__all__ = [
    'BaseTransaction',
    'Transaction',
    'Expense',
    'RecurringExpense',
    'Category',
    'Budget',
    'ExpenseManager'
]
