"""
PennyWise - Personal Expense Tracker
Module: models/category.py
Demonstrates:
- Encapsulation: Category entity with validated name, icon, and optional budget limit
"""

from typing import Dict, Any, Optional


class Category:
    """
    Encapsulates a spending category with metadata for UI visualization.
    """

    DEFAULT_ICONS = {
        "Food": "utensils",
        "Transport": "car",
        "Shopping": "shopping-bag",
        "Education": "graduation-cap",
        "Entertainment": "film",
        "Bills": "receipt",
        "Healthcare": "heart-pulse",
        "Others": "tag"
    }

    DEFAULT_COLORS = {
        "Food": "#10B981",          # Emerald
        "Transport": "#3B82F6",     # Blue
        "Shopping": "#F59E0B",      # Amber
        "Education": "#8B5CF6",     # Purple
        "Entertainment": "#EC4899",  # Pink
        "Bills": "#EF4444",          # Red
        "Healthcare": "#14B8A6",     # Teal
        "Others": "#6B7280"          # Slate
    }

    def __init__(
        self,
        name: str,
        icon: Optional[str] = None,
        color: Optional[str] = None,
        budget_limit: float = 0.0,
        category_id: Optional[int] = None
    ):
        self._id = category_id
        self._name = ""
        self._icon = ""
        self._color = ""
        self._budget_limit = 0.0

        self.name = name
        self.icon = icon or self.DEFAULT_ICONS.get(self._name, "tag")
        self.color = color or self.DEFAULT_COLORS.get(self._name, "#10B981")
        self.budget_limit = budget_limit

    @property
    def id(self) -> Optional[int]:
        return self._id

    @id.setter
    def id(self, val: int) -> None:
        self._id = int(val)

    @property
    def name(self) -> str:
        return self._name

    @name.setter
    def name(self, val: str) -> None:
        if not val or not isinstance(val, str):
            raise ValueError("Category name must be a non-empty string.")
        cleaned = val.strip().title()
        if len(cleaned) < 2 or len(cleaned) > 50:
            raise ValueError("Category name must be between 2 and 50 characters.")
        self._name = cleaned

    @property
    def icon(self) -> str:
        return self._icon

    @icon.setter
    def icon(self, val: str) -> None:
        self._icon = val.strip() if val else "tag"

    @property
    def color(self) -> str:
        return self._color

    @color.setter
    def color(self, val: str) -> None:
        self._color = val.strip() if val else "#10B981"

    @property
    def budget_limit(self) -> float:
        return self._budget_limit

    @budget_limit.setter
    def budget_limit(self, val: Any) -> None:
        try:
            v = float(val)
            self._budget_limit = max(0.0, round(v, 2))
        except (ValueError, TypeError):
            self._budget_limit = 0.0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self._id,
            "name": self._name,
            "icon": self._icon,
            "color": self._color,
            "budget_limit": self._budget_limit
        }

    def __repr__(self) -> str:
        return f"<Category name='{self._name}' color='{self._color}'>"
