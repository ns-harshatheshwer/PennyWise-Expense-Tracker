"""
PennyWise - Personal Expense Tracker
Module: models/expense_manager.py
Demonstrates:
- Composition: ExpenseManager composes DatabaseManager, Budget, Category, and Expense objects
- High-level business logic: Financial calculations, trend analytics, budget utilization, CSV export
"""

from typing import List, Dict, Any, Optional
from datetime import datetime, timedelta
import io
import csv
from collections import defaultdict

from database.db_manager import DatabaseManager
from models.expense import Expense
from models.category import Category
from models.budget import Budget


class ExpenseManager:
    """
    Core Controller / Service layer orchestrating domain entities and persistence.
    Exemplifies Composition by owning and coordinating DatabaseManager, Budget, and Expense entities.
    """

    def __init__(self, db_manager: Any = None):
        # Composition: ExpenseManager owns/uses a DatabaseManager instance
        if isinstance(db_manager, str):
            self._db = DatabaseManager(db_manager)
        elif db_manager is not None:
            self._db = db_manager
        else:
            self._db = DatabaseManager()

    @property
    def database_manager(self) -> DatabaseManager:
        """Getter for database manager instance."""
        return self._db

    # --- Transaction & Expense Management ---

    def create_expense(
        self,
        title: str,
        amount: float,
        date: str,
        category: str = "Others",
        description: str = ""
    ) -> Dict[str, Any]:
        """
        Creates, validates, and stores an Expense entity.
        Returns the serialized dictionary of the persisted entity.
        """
        # Instantiating Expense triggers validation via properties (Encapsulation)
        expense = Expense(
            title=title,
            amount=amount,
            date=date,
            category=category,
            description=description
        )
        saved = self._db.add_expense(expense)
        return saved.to_dict()

    def get_expense(self, expense_id: int) -> Optional[Dict[str, Any]]:
        """Fetch and serialize a single expense."""
        exp = self._db.get_expense_by_id(expense_id)
        return exp.to_dict() if exp else None

    def update_expense(
        self,
        expense_id: int,
        title: str,
        amount: float,
        date: str,
        category: str = "Others",
        description: str = ""
    ) -> bool:
        """Update an existing expense with new parameters."""
        # Validate data by instantiating domain object
        updated_expense = Expense(
            title=title,
            amount=amount,
            date=date,
            category=category,
            description=description,
            transaction_id=expense_id
        )
        return self._db.update_expense(updated_expense)

    def delete_expense(self, expense_id: int) -> bool:
        """Delete an expense record."""
        return self._db.delete_expense(expense_id)

    def list_expenses(
        self,
        search: Optional[str] = None,
        category: Optional[str] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        sort_by: str = "date",
        order: str = "DESC"
    ) -> List[Dict[str, Any]]:
        """Retrieve filtered and sorted expenses as serialized dictionaries."""
        expenses = self._db.get_all_expenses(
            search=search,
            category=category,
            start_date=start_date,
            end_date=end_date,
            sort_by=sort_by,
            order=order
        )
        # Polymorphic call: to_dict()
        return [exp.to_dict() for exp in expenses]

    # --- Budget Operations ---

    def set_budget(
        self,
        amount: float,
        month: Optional[str] = None,
        alert_threshold: float = 80.0
    ) -> Dict[str, Any]:
        """Configure or update budget limit for a month."""
        target_month = month or datetime.now().strftime("%Y-%m")
        budget_obj = Budget(
            monthly_limit=amount,
            month=target_month,
            alert_threshold=alert_threshold
        )
        saved = self._db.save_budget(budget_obj)
        monthly_spent = self.calculate_monthly_total(target_month)
        return saved.to_dict(total_spent=monthly_spent)

    def get_budget(self, month: Optional[str] = None) -> Dict[str, Any]:
        """Get budget status and utilization for a target month."""
        target_month = month or datetime.now().strftime("%Y-%m")
        budget = self._db.get_budget_for_month(target_month)
        
        # If no budget is set for this month, establish a reasonable default ($2,000)
        if not budget:
            budget = Budget(monthly_limit=2000.0, month=target_month, alert_threshold=80.0)
            self._db.save_budget(budget)

        monthly_spent = self.calculate_monthly_total(target_month)
        return budget.to_dict(total_spent=monthly_spent)

    # --- Analytics & Calculations ---

    def calculate_total_expenses(self) -> float:
        """Compute lifetime total of all expenses."""
        all_expenses = self._db.get_all_expenses()
        total = sum(exp.amount for exp in all_expenses)
        return round(total, 2)

    def calculate_monthly_total(self, month: Optional[str] = None) -> float:
        """Calculate total spending strictly within the specified month (YYYY-MM)."""
        target_month = month or datetime.now().strftime("%Y-%m")
        all_expenses = self._db.get_all_expenses()
        # Polymorphic calculate_monthly_impact call
        monthly_sum = sum(exp.calculate_monthly_impact(target_month) for exp in all_expenses)
        return round(monthly_sum, 2)

    def get_category_breakdown(self, month: Optional[str] = None) -> List[Dict[str, Any]]:
        """Calculate spending grouped by category with percentages and UI colors."""
        target_month = month or datetime.now().strftime("%Y-%m")
        all_expenses = self._db.get_all_expenses()
        categories = self._db.get_all_categories()
        cat_meta = {c.name: c for c in categories}

        monthly_expenses = [exp for exp in all_expenses if exp.date.startswith(target_month)]
        month_total = sum(exp.amount for exp in monthly_expenses)

        grouped = defaultdict(float)
        tx_counts = defaultdict(int)
        for exp in monthly_expenses:
            grouped[exp.category] += exp.amount
            tx_counts[exp.category] += 1

        breakdown = []
        for cat_name, amt in sorted(grouped.items(), key=lambda x: x[1], reverse=True):
            meta = cat_meta.get(cat_name)
            percentage = round((amt / month_total * 100), 1) if month_total > 0 else 0.0
            breakdown.append({
                "category": cat_name,
                "amount": round(amt, 2),
                "count": tx_counts[cat_name],
                "percentage": percentage,
                "icon": meta.icon if meta else "tag",
                "color": meta.color if meta else "#10B981",
                "budget_limit": meta.budget_limit if meta else 0.0
            })

        return breakdown

    def get_monthly_trends(self, num_months: int = 6) -> Dict[str, Any]:
        """Aggregate spending across the past N calendar months for trend charts."""
        today = datetime.now()
        months = []
        labels = []

        # Generate list of past N months in chronological order
        for i in range(num_months - 1, -1, -1):
            # Compute approximate date for previous months
            year = today.year
            month = today.month - i
            while month <= 0:
                month += 12
                year -= 1
            dt = datetime(year, month, 1)
            m_str = dt.strftime("%Y-%m")
            months.append(m_str)
            labels.append(dt.strftime("%b %Y"))

        all_expenses = self._db.get_all_expenses()
        monthly_totals = defaultdict(float)
        for exp in all_expenses:
            m_key = exp.date[:7]
            if m_key in months:
                monthly_totals[m_key] += exp.amount

        values = [round(monthly_totals[m], 2) for m in months]

        return {
            "months": months,
            "labels": labels,
            "values": values
        }

    def get_weekly_trends(self) -> Dict[str, Any]:
        """Aggregate spending for the last 7 calendar days."""
        today = datetime.now().date()
        days = []
        labels = []
        daily_totals = defaultdict(float)

        for i in range(6, -1, -1):
            d = today - timedelta(days=i)
            d_str = d.strftime("%Y-%m-%d")
            days.append(d_str)
            labels.append(d.strftime("%a (%d %b)"))

        all_expenses = self._db.get_all_expenses()
        for exp in all_expenses:
            if exp.date in days:
                daily_totals[exp.date] += exp.amount

        values = [round(daily_totals[d], 2) for d in days]

        return {
            "days": days,
            "labels": labels,
            "values": values
        }

    def get_dashboard_summary(self, month: Optional[str] = None) -> Dict[str, Any]:
        """
        Comprehensive data payload for the primary dashboard view:
        - Total lifetime expenses
        - Current month spending
        - Budget status & warning message
        - Recent 5 transactions
        - Category breakdown
        - Monthly trend (6 months)
        - Weekly trend (7 days)
        """
        target_month = month or datetime.now().strftime("%Y-%m")
        all_expenses = self._db.get_all_expenses()
        total_lifetime = round(sum(exp.amount for exp in all_expenses), 2)

        monthly_expenses = [exp for exp in all_expenses if exp.date.startswith(target_month)]
        month_spent = round(sum(exp.amount for exp in monthly_expenses), 2)

        budget_info = self.get_budget(target_month)
        recent_expenses = [exp.to_dict() for exp in all_expenses[:6]]
        category_breakdown = self.get_category_breakdown(target_month)
        monthly_trends = self.get_monthly_trends(6)
        weekly_trends = self.get_weekly_trends()

        # Daily spending statistics for current month
        days_in_month = len(set(exp.date for exp in monthly_expenses)) or 1
        avg_daily = round(month_spent / max(1, datetime.now().day), 2)

        # Top category
        top_category = category_breakdown[0] if category_breakdown else None

        return {
            "total_expenses": total_lifetime,
            "monthly_expenses": month_spent,
            "current_month": target_month,
            "transaction_count": len(all_expenses),
            "monthly_transaction_count": len(monthly_expenses),
            "average_daily_spending": avg_daily,
            "top_category": top_category,
            "budget": budget_info,
            "recent_transactions": recent_expenses,
            "category_breakdown": category_breakdown,
            "monthly_trends": monthly_trends,
            "weekly_trends": weekly_trends
        }

    # --- Categories ---

    def get_categories(self) -> List[Dict[str, Any]]:
        """List all category configurations."""
        categories = self._db.get_all_categories()
        return [c.to_dict() for c in categories]

    def add_category(self, name: str, icon: str = "tag", color: str = "#10B981", limit: float = 0.0) -> Dict[str, Any]:
        """Add a custom category."""
        cat = Category(name=name, icon=icon, color=color, budget_limit=limit)
        saved = self._db.add_category(cat)
        return saved.to_dict()

    # --- Data Persistence Management ---

    def reset_demo_data(self) -> None:
        """Clear existing data and repopulate with fresh sample records."""
        self._db.clear_all_data()
        self._db.seed_sample_data()

    def clear_all_data(self) -> None:
        """Wipe all transactions and budgets."""
        self._db.clear_all_data()

    def export_csv(self) -> str:
        """Export all transactions into a formatted CSV string."""
        expenses = self._db.get_all_expenses(sort_by="date", order="DESC")
        output = io.StringIO()
        writer = csv.writer(output)

        # Write header
        writer.writerow(["ID", "Date", "Title", "Category", "Amount ($)", "Description", "Created At"])

        for exp in expenses:
            writer.writerow([
                exp.id,
                exp.date,
                exp.title,
                exp.category,
                f"{exp.amount:.2f}",
                exp.description,
                exp.created_at
            ])

        return output.getvalue()
