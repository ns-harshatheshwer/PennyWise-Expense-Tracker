"""
PennyWise - Personal Expense Tracker
Module: models/budget.py
Demonstrates:
- Encapsulation: Budget entity encapsulating spending limits, warning thresholds, and state calculations
"""

from typing import Dict, Any, Optional
from datetime import datetime
import re


class Budget:
    """
    Encapsulates budget limits, warning thresholds, and analytics for a target month.
    """

    DEFAULT_THRESHOLD = 80.0  # Alert when 80% spent

    def __init__(
        self,
        monthly_limit: float,
        month: Optional[str] = None,
        alert_threshold: float = DEFAULT_THRESHOLD,
        budget_id: Optional[int] = None,
        updated_at: Optional[str] = None
    ):
        self._id = budget_id
        self._monthly_limit = 0.0
        self._month = ""
        self._alert_threshold = self.DEFAULT_THRESHOLD
        self._updated_at = updated_at or datetime.now().isoformat()

        self.monthly_limit = monthly_limit
        self.month = month or datetime.now().strftime("%Y-%m")
        self.alert_threshold = alert_threshold

    @property
    def id(self) -> Optional[int]:
        return self._id

    @id.setter
    def id(self, val: int) -> None:
        self._id = int(val)

    @property
    def monthly_limit(self) -> float:
        return self._monthly_limit

    @monthly_limit.setter
    def monthly_limit(self, val: Any) -> None:
        try:
            v = float(val)
        except (ValueError, TypeError):
            raise ValueError("Monthly budget limit must be a valid number.")
        if v < 0:
            raise ValueError("Monthly budget limit cannot be negative.")
        self._monthly_limit = round(v, 2)

    @property
    def month(self) -> str:
        return self._month

    @month.setter
    def month(self, val: str) -> None:
        if not val or not isinstance(val, str):
            val = datetime.now().strftime("%Y-%m")
        cleaned = val.strip()
        if not re.match(r"^\d{4}-\d{2}$", cleaned):
            raise ValueError("Month must be in YYYY-MM format.")
        self._month = cleaned

    @property
    def alert_threshold(self) -> float:
        return self._alert_threshold

    @alert_threshold.setter
    def alert_threshold(self, val: Any) -> None:
        try:
            v = float(val)
        except (ValueError, TypeError):
            v = self.DEFAULT_THRESHOLD
        # Constrain threshold between 1% and 100%
        self._alert_threshold = max(1.0, min(100.0, round(v, 1)))

    @property
    def updated_at(self) -> str:
        return self._updated_at

    # --- Business Logic & Calculations ---

    def calculate_remaining(self, total_spent: float) -> float:
        """Calculate remaining unspent budget."""
        return round(self._monthly_limit - total_spent, 2)

    def calculate_utilization(self, total_spent: float) -> float:
        """Calculate percentage of budget used (0 - 100%+)."""
        if self._monthly_limit <= 0:
            return 100.0 if total_spent > 0 else 0.0
        return round((total_spent / self._monthly_limit) * 100, 1)

    def get_status(self, total_spent: float) -> str:
        """
        Determines budget health status:
        - 'exceeded': spent > monthly_limit
        - 'warning': spent >= alert_threshold% of monthly_limit
        - 'safe': spent < alert_threshold% of monthly_limit
        """
        if self._monthly_limit <= 0:
            return "warning" if total_spent == 0 else "exceeded"
        
        utilization = (total_spent / self._monthly_limit) * 100
        if utilization >= 100.0:
            return "exceeded"
        elif utilization >= self._alert_threshold:
            return "warning"
        return "safe"

    def get_warning_message(self, total_spent: float) -> Optional[str]:
        """Provides an actionable human-readable advisory."""
        status = self.get_status(total_spent)
        utilization = self.calculate_utilization(total_spent)
        remaining = self.calculate_remaining(total_spent)

        if status == "exceeded":
            over = abs(remaining)
            return f"Budget exceeded by ${over:,.2f} ({utilization:.1f}% utilized)! Consider reviewing recent expenditures."
        elif status == "warning":
            return f"Attention: You have spent {utilization:.1f}% of your ${self._monthly_limit:,.2f} budget with ${remaining:,.2f} remaining."
        return None

    def to_dict(self, total_spent: float = 0.0) -> Dict[str, Any]:
        """Export budget snapshot including dynamic utilization calculations."""
        remaining = self.calculate_remaining(total_spent)
        utilization = self.calculate_utilization(total_spent)
        status = self.get_status(total_spent)
        warning = self.get_warning_message(total_spent)

        return {
            "id": self._id,
            "month": self._month,
            "monthly_limit": self._monthly_limit,
            "total_spent": round(total_spent, 2),
            "remaining": remaining,
            "utilization_percentage": utilization,
            "alert_threshold": self._alert_threshold,
            "status": status,
            "warning_message": warning,
            "updated_at": self._updated_at
        }

    def __repr__(self) -> str:
        return f"<Budget month='{self._month}' limit=${self._monthly_limit:.2f}>"
