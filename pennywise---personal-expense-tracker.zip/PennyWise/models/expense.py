"""
PennyWise - Personal Expense Tracker
Module: models/expense.py
Demonstrates:
- Inheritance: Expense inherits from Transaction
- Polymorphism: Overridden to_dict, summary, and monthly impact methods
- Specialization: RecurringExpense subclass demonstrating deeper inheritance
"""

from typing import Dict, Any, Optional
from datetime import datetime
from .transaction import Transaction


class Expense(Transaction):
    """
    Represents an expense entry.
    Inherits from Transaction and introduces categorization and category validation.
    """

    ALLOWED_DEFAULT_CATEGORIES = [
        "Food",
        "Transport",
        "Shopping",
        "Education",
        "Entertainment",
        "Bills",
        "Healthcare",
        "Others"
    ]

    def __init__(
        self,
        title: str,
        amount: float,
        date: str,
        category: str = "Others",
        description: str = "",
        transaction_id: Optional[int] = None,
        created_at: Optional[str] = None
    ):
        # Call superclass constructor (demonstrates Inheritance)
        super().__init__(
            title=title,
            amount=amount,
            date=date,
            description=description,
            transaction_id=transaction_id,
            created_at=created_at
        )
        self._category: str = "Others"
        self.category = category

    @property
    def category(self) -> str:
        """Getter for expense category."""
        return self._category

    @category.setter
    def category(self, value: str) -> None:
        """Setter with category sanitization."""
        if not value or not isinstance(value, str):
            self._category = "Others"
        else:
            cleaned = value.strip().title()
            self._category = cleaned if cleaned else "Others"

    # --- Polymorphism: Overridden methods ---

    def summary(self) -> str:
        """Polymorphic override of summary displaying category."""
        return f"[{self.date}] ({self.category}) {self.title}: -${self.amount:.2f}"

    def to_dict(self) -> Dict[str, Any]:
        """Polymorphic override of to_dict incorporating category information."""
        base_dict = super().to_dict()
        base_dict.update({
            "category": self.category,
            "type": "expense"
        })
        return base_dict

    def __repr__(self) -> str:
        return f"<Expense id={self.id} title='{self.title}' amount={self.amount} category='{self.category}'>"


class RecurringExpense(Expense):
    """
    Subclass of Expense for recurring commitments (e.g. Netflix, Gym, Rent).
    Demonstrates multi-level Inheritance and Polymorphism.
    """

    VALID_FREQUENCIES = ["daily", "weekly", "monthly", "yearly"]

    def __init__(
        self,
        title: str,
        amount: float,
        date: str,
        category: str = "Bills",
        frequency: str = "monthly",
        description: str = "",
        transaction_id: Optional[int] = None,
        created_at: Optional[str] = None
    ):
        super().__init__(
            title=title,
            amount=amount,
            date=date,
            category=category,
            description=description,
            transaction_id=transaction_id,
            created_at=created_at
        )
        self._frequency: str = "monthly"
        self.frequency = frequency

    @property
    def frequency(self) -> str:
        return self._frequency

    @frequency.setter
    def frequency(self, val: str) -> None:
        cleaned = val.strip().lower() if val else "monthly"
        if cleaned not in self.VALID_FREQUENCIES:
            raise ValueError(f"Frequency must be one of {self.VALID_FREQUENCIES}")
        self._frequency = cleaned

    def calculate_monthly_impact(self, target_month: Optional[str] = None) -> float:
        """
        Polymorphic calculation: computes normalized monthly expenditure based on frequency.
        """
        if self._frequency == "daily":
            return round(self.amount * 30, 2)
        elif self._frequency == "weekly":
            return round(self.amount * 4.33, 2)
        elif self._frequency == "monthly":
            return self.amount
        elif self._frequency == "yearly":
            return round(self.amount / 12, 2)
        return self.amount

    def to_dict(self) -> Dict[str, Any]:
        d = super().to_dict()
        d.update({
            "frequency": self._frequency,
            "type": "recurring_expense",
            "monthly_impact": self.calculate_monthly_impact()
        })
        return d
